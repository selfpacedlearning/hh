const mongoose = require("mongoose");
const connectDB = require("./config/dbConn");
const express = require("express");
const app = express();
const path = require("path");
const { Downloader } = require("nodejs-file-downloader");
const User = require("./model/User");
const PORT = process.env.PORT || 3000;

// set the view engine to ejs
app.set("view engine", "ejs");

// Connect to MongoDB
connectDB();

app.use(express.json({ limit: "100mb", extended: true }));
app.use(
  express.urlencoded({ limit: "100mb", extended: true, parameterLimit: 1000 })
);

//serve static files
app.use("/", express.static(path.join(__dirname, "/public")));

app.use("/", require("./routes/root"));

app.get("/message/:id", function (req, res) {
  console.log(req.params);
  (async () => {
    await bot.api.sendMessage(req.params.id, "تراکنش شما تایید شد.");
  })();
});

app.all("*", (req, res) => {
  res.status(404);
  if (req.accepts("html")) {
    res.sendFile(path.join(__dirname, "views", "404.html"));
  } else if (req.accepts("json")) {
    res.json({ error: "404 Not Found" });
  } else {
    res.type("txt").send("404 Not Found");
  }
});

mongoose.connection.once("open", () => {
  console.log("Connected to MongoDB");
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
});

const { Bot, Keyboard, InputFile } = require("grammy");

// const bot = new Bot("7317078886:AAGUktFxiIGWk8vZJYLYJMHPNZRXTRV0BVQ");
const bot = new Bot("7031900641:AAFgX2NyFZfEa5yxzoXzuqSIBmhdemd9y3k"); //test

const keyboard = new Keyboard();
keyboard.text("خرید اشتراک").row();
keyboard.text("آموزش‌ها").row();
keyboard.text("ارتباط با پشتیبانی").row();
keyboard.text("بازگشت به صفحه اصلی").row();

bot.command("start", (ctx) => {
  ctx.reply(
    "به بات گیم‌پینگ خوش آمدید..." + "\n" + "از زیر لیست زیر انتخاب کنید",
    {
      reply_markup: keyboard,
    }
  );
});

bot.on("message:text", async (ctx) => {
  try {
    if (ctx.msg.text == "بازگشت به صفحه اصلی") {
      const keyboard = new Keyboard();
      keyboard.text("خرید اشتراک").row();
      keyboard.text("آموزش‌ها").row();
      keyboard.text("ارتباط با پشتیبانی").row();
      keyboard.text("بازگشت به صفحه اصلی").row();

      ctx.reply("از لیست زیر انتخاب کنید", {
        reply_markup: keyboard,
      });
    } else if (ctx.msg.text == "خرید اشتراک") {
      const keyboard = new Keyboard();
      keyboard.text("در سایت گیم پینگ ثبت‌نام کرده‌ام").row();
      keyboard.text("در سایت گیم پینگ ثبت‌نام نکرده‌ام").row();

      keyboard.text("بازگشت به صفحه اصلی").row();
      ctx.reply("از لیست زیر انتخاب کنید", {
        reply_markup: keyboard,
      });
    } else if (ctx.msg.text == "در سایت گیم پینگ ثبت‌نام نکرده‌ام") {
      ctx.reply(
        "لطفا برای ثبت‌نام به سایت زیر مراجعه کنید" +
          "\n" +
          "https://www.gameping.top/register"
      );
    } else if (ctx.msg.text == "در سایت گیم پینگ ثبت‌نام کرده‌ام") {
      const keyboard = new Keyboard();
      keyboard.text("شارژ کیف پول").row();
      keyboard.text("خرید بسته").row();
      keyboard.text("بازگشت به صفحه اصلی").row();

      ctx.reply("از لیست زیر انتخاب کنید", {
        reply_markup: keyboard,
      });
    } else if (ctx.msg.text == "شارژ کیف پول") {
      ctx.reply(
        "لطفا مبلغ دلخواه را به شماره کارت زیر واریز نمایید و سپس رسید آن را در همینجا ارسال نمایید." +
          "\n" +
          "6219861903048394 به نام پاک‌نژاد" +
          "\n" +
          "لازم به ذکر است که زمان پردازش از 1 الی 12 ساعت ممکن است طول بکشد." +
          "\n" +
          "همچنین ایمیل ثبت‌نام شده در گیم‌پینگ را نیز وارد کنید."
      );
    } else if (ctx.msg.text == "خرید بسته") {
      ctx.reply(
        "بسته‌ها به صورت زیر است:" +
          "\n" +
          "یک ماهه:" +
          "\n" +
          "1- 35 گیگ --> 95 هزار تومان" +
          "\n" +
          "2- 125 گیگ --> 250 هزار تومان" +
          "\n" +
          "3- 200 گیگ --> 299 هزار تومان" +
          "\n" +
          "\n" +
          "سه ماهه" +
          "\n" +
          "1- 100 گیگ --> 225 هزار تومان" +
          "\n" +
          "2- 250 گیگ --> 499 هزار تومان" +
          "\n" +
          "3- 375 گیگ --> 699 هزار تومان" +
          "\n" +
          "\n" +
          "ترافیک اضافه (خرید حجم)" +
          "\n" +
          "1- 50 گیگ --> 125 هزار تومان" +
          "\n" +
          "2- 100 گیگ --> 189 هزار تومان"
      );
      ctx.reply(
        "لطفا مبلغ دلخواه را به شماره کارت زیر واریز نمایید و سپس رسید آن را در همینجا ارسال نمایید." +
          "\n" +
          "6219861903048394 به نام پاک‌نژاد" +
          "\n" +
          "لازم به ذکر است که زمان پردازش از 1 الی 12 ساعت ممکن است طول بکشد." +
          "\n" +
          "همچنین ایمیل ثبت‌نام شده در گیم‌پینگ را نیز وارد کنید."
      );
    } else if (ctx.msg.text == "آموزش‌ها") {
      const keyboard = new Keyboard();
      keyboard.text("اندروید").row();
      keyboard.text("آیفون").row();
      keyboard.text("ویندوز").row();
      keyboard.text("بازگشت به صفحه اصلی").row();

      ctx.reply("از لیست زیر انتخاب کنید", {
        reply_markup: keyboard,
      });
    } else if (ctx.msg.text == "اندروید") {
      ctx.reply("https://t.me/helpsaghi/149");
    } else if (ctx.msg.text == "آیفون") {
      ctx.reply("https://t.me/helpsaghi/138");
    } else if (ctx.msg.text == "ویندوز") {
      ctx.reply("https://t.me/helpsaghi/133");
    } else if (ctx.msg.text == "ارتباط با پشتیبانی") {
      ctx.reply(
        "در صورت داشتن هر گونه سوال، به آیدی زیر پیام دهید:" +
          "\n" +
          "@Spsaghivpn"
      );
    } else if (ctx.msg.text.includes("@") > 0) {
      const result = {
        chatId: ctx.chat.id,
        firstname: ctx.chat.first_name,
        username: ctx.chat.username,
        email: ctx.msg.text,
        factorId: "",
      };
      await User.create(result);

      ctx.reply("ایمیل دریافت شد");
    } else {
      ctx.reply("دوباره تلاش کنید");
    }
  } catch {}
});

bot.on("message:photo", async (ctx) => {
  const file = await ctx.getFile(); // valid for at least 1 hour
  const filepath = file.file_path; // file path on Bot API server

  const rand = Math.round(Math.random() * 1000000000000);

  const downloader = new Downloader({
    url:
      "https://api.telegram.org/file/bot7031900641:AAFgX2NyFZfEa5yxzoXzuqSIBmhdemd9y3k/" +
      filepath,
    directory: "./public/factors", //This folder will be created, if it doesn't exist.
    maxAttempts: 3, //Default is 1.
    fileName: rand + ".png",
  });
  try {
    const { filePath, downloadStatus } = await downloader.download(); //Downloader.download() resolves with some useful properties.

    const result = {
      chatId: ctx.chat.id,
      firstname: ctx.chat.first_name,
      username: ctx.chat.username,
      email: "",
      factorId: rand,
    };
    await User.create(result);

    ctx.reply("تصویر دریافت شد");

    console.log("All done");
  } catch (error) {
    //IMPORTANT: Handle a possible error. An error is thrown in case of network errors, or status codes of 400 and above.
    //Note that if the maxAttempts is set to higher than 1, the error is thrown only if all attempts fail.
    console.log("Download failed");
  }
});

// Start the bot
bot.start({
  allowed_updates: ["message"],
});
