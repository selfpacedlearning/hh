const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  chatId: { type: Schema.Types.Mixed },
  firstname: { type: Schema.Types.Mixed },
  username: { type: Schema.Types.Mixed, index: true },
  email: { type: Schema.Types.Mixed, index: true },
  factorId: { type: Schema.Types.Mixed },
});

module.exports = mongoose.model("User", UserSchema);
