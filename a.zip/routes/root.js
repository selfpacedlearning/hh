const express = require("express");
const router = express.Router();
const path = require("path");

const User = require("../model/User");

router.get("^/$|/index(.html)?", (req, res) => {
  (async () => {
    const users = await User.find().sort({ _id: -1 });

    username = [];
    chatId = [];
    firstname = [];
    result = [];

    for (let i = 0; i < users.length; i++) {
      if (username.indexOf(users[i].username) == -1) {
        username.push(users[i].username);
        chatId.push(users[i].chatId);
        firstname.push(users[i].firstname);
      }
    }

    for (let i = 0; i < username.length; i++) {
      var selectedEmails = [];
      var selectedFactorIds = [];
      for (let j = 0; j < users.length; j++) {
        if (users[j].username == username[i]) {
          if (users[j].email != "" && users[j].email != undefined)
            selectedEmails.push(users[j].email);
          if (users[j].factorId != "" && users[j].factorId != undefined)
            selectedFactorIds.push(users[j].factorId);
        }
      }

      result[i] = {
        chatId: chatId[i],
        firstname: firstname[i],
        username: username[i],
        email: selectedEmails,
        factorId: selectedFactorIds,
      };
    }

    res.render("index", {
      data: result,
    });
  })();
});

module.exports = router;
